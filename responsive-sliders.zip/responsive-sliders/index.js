// $(document).ready(function() {
//     let pressed = false;
//     let startX = 0;

//     $('.skslider-container').mousedown(function(e) {
//         pressed = true;
//         startX = e.clientX;
//         $(this).css('cursor','grabbing');
//     });

//     $('.skslider-container').mouseleave(function() {
//         pressed = false;
//     });

//     $('.skslider-container').mouseup(function() {
//         pressed = false;
//         $(this).css('cursor','grab');
//     });

//     $('.skslider-container').mousemove(function(e) {
//         if (!pressed) {
//             return
//         }
//         this.scrollLeft += startX - e.clientX;
//     });

// });

$(function () {
    let clickcount = 0;
    $("#coverflow").flipster({
        style: 'wheel',
        spacing: 0.05,
        buttons: true,
        loop: false,
        scrollwheel: false,
        Touch: true,
        // onItemSwitch: function() {
        //     clickcount +=1;
        //     if (clickcount < 5) {
        //         $(".flipster__item--current").prevAll('li').clone().appendTo('#coverflow .flip-items');
        //         $("#coverflow").flipster('index');
        //     } 
        // },
        // autoplay: 3000
    });

    // $("#flat-coverflow").flipster({
    //     style: 'flat',
    //     spacing: -0.2,
    //     buttons: true,
    //     loop: false,
    //     scrollwheel: false,
    //     Touch: true,
    // });

    $('body').on('click', '.flipster__button--next', function() {
        clickcount +=1;
        if (clickcount == 1) {
            $(".flipster__item--current").prevAll('li').clone().appendTo('#coverflow .flip-items');
            $("#coverflow").flipster('index');
        } else {
            if ($(".flipster__item--current").index() === $(".flipster__item").length - 3) {
                $(".flipster__item--current").prevAll('li').clone().appendTo('#coverflow .flip-items');
                $("#coverflow").flipster('index');
            }
        }  
    });
});